<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $full_name = $_POST["full_name"];
    $email = $_POST["email"];
    $password = $_POST["pass"];
    $confirm_password = $_POST["con_pass"];
    $phone = $_POST["phone"];
    $qualifications = $_POST["qualifications"];
    $expertise = $_POST["expertise"];
    $profile_picture = $_FILES["profile_picture"];
    $teaching_experience = $_POST["T_experience"];
    $institution = $_POST["institution"];

    // Validate the form data
    $errors = [];

    // Validate full name
    if (empty($full_name)) {
        $errors['full_name'] = "Full Name is required.";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $full_name)) {
        $errors['full_name'] = "Full Name can only contain letters and spaces.";
    }

    // Validate email
    if (empty($email)) {
        $errors['email'] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Invalid email format.";
    }

    // Validate password
    if (empty($password)) {
        $errors['pass'] = "Password is required.";
    } elseif (strlen($password) < 8) {
        $errors['pass'] = "Password must be at least 8 characters.";
    }

    // Validate confirm password
    if (empty($confirm_password)) {
        $errors['con_pass'] = "Please confirm your password.";
    } elseif ($password !== $confirm_password) {
        $errors['con_pass'] = "Passwords do not match.";
    }

    // Validate phone number
    if (empty($phone)) {
        $errors['phone'] = "Phone Number is required.";
    } elseif (!preg_match("/^[0-9]{10}$/", $phone)) {
        $errors['phone'] = "Phone Number must be exactly 10 digits.";
    }

    // Validate qualifications
    if (empty($qualifications)) {
        $errors['qualifications'] = "Qualifications are required.";
    }

    // Validate expertise
    if (empty($expertise)) {
        $errors['expertise'] = "Please select an area of expertise.";
    }

    // Validate teaching experience
    if (empty($teaching_experience)) {
        $errors['T_experience'] = "Teaching experience is required.";
    } elseif (!is_numeric($teaching_experience) || $teaching_experience < 0) {
        $errors['T_experience'] = "Teaching experience must be a positive number.";
    }

    // Validate institution
    if (empty($institution)) {
        $errors['institution'] = "Institution is required.";
    }

    // Validate profile picture
    if (!empty($profile_picture["name"])) {
        $allowed_types = ["image/jpg", "image/jpeg", "image/png", "image/gif"];
        if (!in_array($profile_picture["type"], $allowed_types)) {
            $errors['profile_picture'] = "Profile picture must be an image (JPG, JPEG, PNG, GIF).";
        }
    }

    // If there are no errors, store the data in a JSON file
    if (empty($errors)) {
        $user_data = array(
            "full_name" => $_POST['full_name'],
            "email" => $_POST['email'],
            "phone" => $_POST['phone'],
            "qualifications" => $_POST['qualifications'],
            "expertise" => $_POST['expertise'],
            "teaching_experience" => $_POST['teaching_experience'],
            "institution" => $_POST['institution']
        );

        $json_data = json_encode($user_data, JSON_PRETTY_PRINT);
        file_put_contents("../data/userdata.json", $json_data);

        echo "User data saved to userdata.json file.";
    } else {
        // Display the errors
        echo "<h2>Please correct the following errors:</h2>";
        echo "<ul>";
        foreach ($errors as $error) {
            echo "<li>" . $error . "</li>";
        }
        echo "</ul>";
    }
}
?>

</body>
</html>
